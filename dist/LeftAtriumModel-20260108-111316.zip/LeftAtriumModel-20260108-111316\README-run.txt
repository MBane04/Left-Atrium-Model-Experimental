﻿Left Atrium Model - Portable Package

Requirements:
- Windows with NVIDIA CUDA-enabled GPU and current drivers
- CUDA Toolkit and MSVC runtime installed
- FFmpeg (optional) for Record Video/Screenshot:
  winget install --id Gyan.FFmpeg -e

Run:
- Double-click svt.exe or run from PowerShell:
  .\\svt.exe

Simulation setups:
- BasicSimulationSetup, IntermediateSimulationSetup, AdvancedSimulationSetup included.
- To use a setup, replace the contents of simulationSetup.txt with one of the setup files.

Data:
- NodesMuscles contains the available meshes.
- PreviousRunsFile contains demo run files and a place to save your runs.

